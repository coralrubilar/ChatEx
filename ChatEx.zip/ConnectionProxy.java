package il.ac.shenkar.practic.chat;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ConnectionProxy extends Thread implements StringConsumer, StringProducer{
    private Socket chatSock;
    private DataOutputStream out;
    private DataInputStream in;
    private StringConsumer sc;
    private ClientDescriptor cd;
    Thread reader;
    /* Used by server */
    public ConnectionProxy(Socket s){
        chatSock = s;

        try {
            out = new DataOutputStream(chatSock.getOutputStream());
            in = new DataInputStream(chatSock.getInputStream());
        }
        catch (IOException e){
            e.printStackTrace();
            System.exit(-1);
        }

    }

    /* Used by client */
    public ConnectionProxy(String[] info) throws IOException {

        try {
            chatSock = new Socket(info[1], Integer.parseInt(info[2]));
            out = new DataOutputStream(chatSock.getOutputStream());
            in = new DataInputStream(chatSock.getInputStream());
            out.writeUTF(info[0]);
        }
        catch (IOException e){
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void consume(String str) {
        try {
            out.writeUTF(str);
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void addConsumer(StringConsumer sc) {
        this.sc = sc;
        if(sc.getClass() == ClientDescriptor.class){
            this.cd = (ClientDescriptor) sc;
            try{
                cd.setClientName(in.readUTF());
            }
            catch(IOException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void removeConsumer(StringConsumer sc) {
        cd.removeConsumer(this);
    }

    public String getClientName(){
        return cd.getClientName();
    }

    public void stopReader(){
        if(reader != null){
            reader.interrupt();
        }
        return;
    }

    @Override
    public void run(){
        String msg;
        reader = Thread.currentThread();
        while(true){
            try{
                if(Thread.interrupted()){
                    return;
                }

                msg = in.readUTF();
                if(msg.equals("./DISCONNECTED")){
                    removeConsumer(sc);
                    break;
                }

                sc.consume(msg);
            }
            catch(IOException e){
                e.printStackTrace();
                sc.consume("./DISCONNECTED");
                return;
            }
        }
    }
}