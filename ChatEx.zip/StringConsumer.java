package il.ac.shenkar.practic.chat;

public interface  StringConsumer

{

    public void consume(String str);

}
