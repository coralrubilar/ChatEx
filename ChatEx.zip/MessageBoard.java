package il.ac.shenkar.practic.chat;

import java.util.Vector;

public class MessageBoard implements StringConsumer, StringProducer{
    private Vector<StringConsumer> consumers;

    public MessageBoard(){
        consumers = new Vector<>();
    }

    @Override
    public void consume(String str) {
        if(consumers.size() == 0){
            return;
        }

        for (StringConsumer sc : consumers) {
            sc.consume(str);
        }
    }

    @Override
    public void addConsumer(StringConsumer sc) {
        consumers.add(sc);
        if(sc.getClass() == ConnectionProxy.class){
            ConnectionProxy cp = (ConnectionProxy) sc;
            consume( cp.getClientName() + " Has Joined The Chat! Say Hi!!!");
        }
    }

    @Override
    public void removeConsumer(StringConsumer sc) {
        consumers.remove(sc);
        if(sc.getClass() == ConnectionProxy.class){
            ConnectionProxy cp = (ConnectionProxy) sc;
            this.consume( cp.getClientName() + " Has Left The Chat!");
        }
    }
}