package il.ac.shenkar.practic.chat;


public class ClientDescriptor implements StringConsumer, StringProducer{
 private StringConsumer sc;
 private MessageBoard mb;
 private String clientName;

 public ClientDescriptor() {
  clientName = new String();
 }

 @Override
 public void consume(String str) {
  sc.consume(clientName + ": " + str);
 }

 @Override
 public void addConsumer(StringConsumer sc) {
  this.sc = sc;
  if(MessageBoard.class == sc.getClass()){
   this.mb = (MessageBoard) sc;
  }
 }

 @Override
 public void removeConsumer(StringConsumer sc) {
  mb.removeConsumer(sc);
 }

 public void setClientName(String clientName) {
  this.clientName = clientName;
 }

 public String getClientName() {
  return clientName;
 }
}

