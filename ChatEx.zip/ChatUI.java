package il.ac.shenkar.practic.chat;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class ChatUI implements StringConsumer, StringProducer{
    private JFrame frame;
    private JPanel topPanel, botPanel;
    private JButton send, connect, disconnect;
    private JTextField nick, ip, port, line;
    private JTextArea cWindow;
    private JScrollPane scroll;
    private JLabel nickn, ipn,portn,linen;
    private ConnectionProxy proxy;
    private StringConsumer sc;


    public ChatUI() {
        frame = new JFrame("My Chat");
        frame.setLayout(new BorderLayout());
        topPanel = new JPanel();
        botPanel = new JPanel();
        send = new JButton("Send");
        connect = new JButton("Connect");
        disconnect = new JButton("Disconnect");
        nick = new JTextField(10);
        nick.setText("user name");
        ip = new JTextField(10);
        ip.setText("127.0.0.1");
        port = new JTextField(10);
        port.setText("1300");
        line = new JTextField(50);
        line.setEditable(false);
        nickn = new JLabel("Nickname: ");
        ipn = new JLabel("IP: ");
        portn = new JLabel("Port: ");
        linen = new JLabel("Line: ");
        cWindow = new JTextArea(20, 20);
        cWindow.setFont(new Font("Ariel", Font.PLAIN, 14));
        cWindow.setEditable(false);
        Border border = BorderFactory.createLineBorder(Color.BLACK);
        cWindow.setBorder(BorderFactory.createCompoundBorder(border,
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        scroll = new JScrollPane(cWindow);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setPreferredSize(new Dimension(600, 300));

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if(proxy != null){
                    proxy.consume("./DISCONNECTED");
                }

                super.windowClosing(e);
                System.exit(1);
            }
        });

        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(line.getText().isEmpty())
                    return;

                proxy.consume(line.getText());
                line.setText("");
            }
        });

        line.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(line.getText().isEmpty())
                    return;

                proxy.consume(line.getText());
                line.setText("");
            }
        });

        disconnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                proxy.consume("./DISCONNECTED");
                proxy.stopReader();
                disconnect.setEnabled(false);
                connect.setEnabled(true);
                send.setEnabled(false);
                line.setEditable(false);
                connect.setEnabled(true);
                nick.setEditable(true);
                ip.setEditable(true);
                port.setEditable(true);
                line.setEditable(false);
                consume("Disconnected From Server!");
            }
        });

        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cWindow.append("Attempting to connect...\n");
                if (ip.getText().isEmpty() || nick.getText().isEmpty() || port.getText().isEmpty()) {
                    cWindow.append("\nPlease enter all of the following: Nickname, IP, Port.");
                    return;
                }

                String[] info = new String[3];
                info[0] = nick.getText();
                info[1] = ip.getText();
                info[2] = port.getText();

                try {
                    proxy = new ConnectionProxy(info);
                }
                catch (IOException e1) {
                    cWindow.append("Connection Failed!\nPlease Check Server Information And Try Again(Server Might Be Down)!\n");
                    return;
                }

                proxy.addConsumer(ChatUI.this);
                ChatUI.this.addConsumer(proxy);
                consume("Connected!");

                proxy.start();
                disconnect.setEnabled(true);
                send.setEnabled(true);
                connect.setEnabled(false);
                nick.setEditable(false);
                ip.setEditable(false);
                port.setEditable(false);
                line.setEditable(true);
            }
        });
    }

    @Override

    public void consume(String str) {
        if(str.equals("./DISCONNECTED")){
            removeConsumer(sc);
            cWindow.append("Server Disconnected!!" + '\n');
            disconnect.setEnabled(false);
            send.setEnabled(false);
            connect.setEnabled(true);
            nick.setEditable(true);
            ip.setEditable(true);
            port.setEditable(true);
            return;
        }
        cWindow.append(str + '\n');
    }

    @Override
    public void addConsumer(StringConsumer sc) {
        this.sc = sc;
    }

    @Override
    public void removeConsumer(StringConsumer sc) {
        this.sc = null;
    }

    public void start(){
        topPanel.add(nickn);
        topPanel.add(nick);
        topPanel.add(ipn);
        topPanel.add(ip);
        topPanel.add(portn);
        topPanel.add(port);
        topPanel.add(connect);
        topPanel.add(disconnect);
        botPanel.add(linen);
        botPanel.add(line);
        botPanel.add(send);
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(botPanel, BorderLayout.SOUTH);
        frame.add(scroll);
        frame.setSize(800,500);
        frame.setVisible(true);
        send.setEnabled(false);
        disconnect.setEnabled(false);
    }
}

class ChatDemo{
    static ChatUI myChat;
    public static void main(String[] args){
        myChat = new ChatUI();
        myChat.start();

        ChatUI sec = new ChatUI();
        sec.start();

    }
}